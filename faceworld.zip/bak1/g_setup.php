<?PHP
include 'config.php';
session_start();

///////////////////////////////////////////////////////////////////////
date_default_timezone_set('America/Kentucky/Monticello');


$month = $_SESSION['month'];
$month = stripslashes($month);
$month = strip_tags($month);
$day = $_SESSION['day'];
$day = stripslashes($day);
$day = strip_tags($day);
$year = $_SESSION['year'];
$year = stripslashes($year);
$year = strip_tags($year);
$sex = $_SESSION['sex'];
$sex = stripslashes($sex);
$sex = strip_tags($sex);
$email = $_SESSION['email'];
$email = stripslashes($email);
$email = strip_tags($email);
$password = $_SESSION['password'];
$password = stripslashes($password);
$password = strip_tags($password);
$firstname = $_SESSION['firstname'];
$firstname = stripslashes($firstname);
$firstname = strip_tags($firstname);
$lastname = $_SESSION['lastname'];
$lastname = stripslashes($lastname);
$lastname = strip_tags($lastname);
$zipcode = $_SESSION['zipcode'];
$zipcode = stripslashes($zipcode);
$zipcode = strip_tags($zipcode);
//////////////////////////////////////////////////////////


$query = "SELECT * FROM profile WHERE email = '$email'";
$result = mysql_query($query)
or die("Query failed: " . mysql_error());
while ($row = mysql_fetch_assoc($result))
{
$email2 = $row['email']; 		
}

if($email == $email2)
{
header ("location: https://certs.godaddy.com/cert/details/bl6in8e2cpfiz4eugs3hmbkj8zotgz1u://www.faceworld.io/index.php");	
}



else
{


if(!empty($email))
{

if(!empty($password))
{

if(!empty($firstname))
{

if(!empty($lastname))
{

if($sex != "Select Sex")
{

if($month != "Month")
{

if($day != "Day")
{

if($year != "Year")
{




if($_FILES["fileToUpload"]["tmp_name"])
{

$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image

    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
       // echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
      //  echo "File is not an image.";
        $uploadOk = 0;
    }

// Check if file already exists
if (file_exists($target_file)) {
  // echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
//if ($_FILES["fileToUpload"]["size"] > 500000) {
  //  echo "Sorry, your file is too large.";
   // $uploadOk = 0;
//}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  //  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
 //   echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
	
	$file = basename($_FILES["fileToUpload"]["name"]);
	$hash = md5(uniqid(rand(), true));
	list($filename, $ext) = explode(".", $file);
	$f = $hash.'.'.$ext;
	$target_file = 'uploads/'.$f;
	

	
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
       // echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
    } else {
    //    echo "Sorry, there was an error uploading your file.";
    }
}

}









///////////////////////////////////////////////////////////


$id = abs(rand(111111111111, 999999999999999));
$time = date("Y-m-d H:i:s");



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////


$signquery4 = "CREATE TABLE IF NOT EXISTS profile(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), password VARCHAR(30), month VARCHAR(10), day VARCHAR(10), year VARCHAR(100), sex VARCHAR(50), phone VARCHAR(300), photo VARCHAR(500), views VARCHAR(500), interactions VARCHAR(500), location VARCHAR(500), type VARCHAR(500), doctor VARCHAR(500), nurse VARCHAR(500), other VARCHAR(500), time TIMESTAMP)";

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());



$signup = "INSERT INTO profile(id, user_id, firstname, lastname, email, password, month, day, year, sex, phone, photo, views, interactions, location, type, doctor, nurse, other, time) VALUES (NULL, '$id', '$firstname', '$lastname', '$email', '$password', '$month', '$day', '$year', '$sex', '', '$f', '$person', 'Single', '$location', '', '', '', '$zipcode', '$time')";  mysql_query($signup) or die('Error, insert query failed, oh shoot, it failed.---------------2a');






//////////////////////////////////////////////////////////////////////////////////////////////////////////////////


$signquery4 = "CREATE TABLE IF NOT EXISTS date_chat(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), question LONGTEXT, response LONGTEXT, autotalkon VARCHAR(10), likes VARCHAR(1000), photo VARCHAR(500), views VARCHAR(500), interactions VARCHAR(500), time TIMESTAMP)";  

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());


$signquery4 = "CREATE TABLE IF NOT EXISTS date_shares(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), question LONGTEXT, response LONGTEXT, autotalkon VARCHAR(10), likes VARCHAR(1000), photo VARCHAR(500), views VARCHAR(500), interactions VARCHAR(500), shares VARCHAR(500), time TIMESTAMP)";  

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());


$signquery4 = "CREATE TABLE IF NOT EXISTS date_likes(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), question LONGTEXT, response LONGTEXT, autotalkon VARCHAR(10), likes VARCHAR(1000), photo VARCHAR(500), views VARCHAR(500), interactions VARCHAR(500), time TIMESTAMP)";  

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());




$signquery4 = "CREATE TABLE IF NOT EXISTS find_dates(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), password VARCHAR(30), month VARCHAR(10), day VARCHAR(10), year VARCHAR(100), sex VARCHAR(50), phone VARCHAR(300), photo VARCHAR(500), views VARCHAR(500), interactions VARCHAR(500), time TIMESTAMP)";

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());




$signquery4 = "CREATE TABLE IF NOT EXISTS date_requests(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), password VARCHAR(30), month VARCHAR(10), day VARCHAR(10), year VARCHAR(100), sex VARCHAR(50), photo VARCHAR(500), check_mark VARCHAR(500), views VARCHAR(500), interactions VARCHAR(500), time TIMESTAMP)";

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());




$signquery4 = "CREATE TABLE IF NOT EXISTS dates(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), password VARCHAR(30), month VARCHAR(10), day VARCHAR(10), year VARCHAR(100), sex VARCHAR(50), photo VARCHAR(500), check_mark VARCHAR(500), views VARCHAR(500), interactions VARCHAR(500), time TIMESTAMP)";

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());





$signquery4 = "CREATE TABLE IF NOT EXISTS settings(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), deactivate VARCHAR(50), send_emails VARCHAR(50), sound VARCHAR(50), stealthmode VARCHAR(50), delete_account VARCHAR(50), views VARCHAR(500), interactions VARCHAR(500), time TIMESTAMP)";

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$date_chat = 'date_chat'.'_'.$id;
$date_shares = 'date_shares'.'_'.$id;
$date_likes = 'date_likes'.'_'.$id;
$dates = 'dates'.'_'.$id;
$date_requests = 'date_requests'.'_'.$id;
$info = 'info'.'_'.$id;
$settings = 'settings'.'_'.$id;
$find_dates = 'find_dates'.'_'.$id;
$photos = 'photos'.'_'.$id;
$profile_stored = 'profile_stored'.'_'.$id;





////////////////////////////////////////////////////////////////////////////////////////////////////

$query = "SELECT * FROM profile WHERE user_id = '$id'";
$result = mysql_query($query)
or die("Query failed: " . mysql_error());
while ($row = mysql_fetch_assoc($result))
{
$city = $row['city'];
$state = $row['state'];	
	
}

$profile_stored = 'profile_stored'.'_'.$id;


///////////////////////////////////////////////////////////////////////////////////////////////////

$signquery4 = "CREATE TABLE IF NOT EXISTS $dates(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), password VARCHAR(30), month VARCHAR(10), day VARCHAR(10), year VARCHAR(100), sex VARCHAR(50), photo VARCHAR(500), check_mark VARCHAR(500), views VARCHAR(500), interactions VARCHAR(500), time TIMESTAMP)";

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());




$signquery4 = "CREATE TABLE IF NOT EXISTS dates(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), password VARCHAR(30), month VARCHAR(10), day VARCHAR(10), year VARCHAR(100), sex VARCHAR(50), photo VARCHAR(500), check_mark VARCHAR(500), views VARCHAR(500), interactions VARCHAR(500), time TIMESTAMP)";

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());




$signquery4 = "CREATE TABLE IF NOT EXISTS $date_chat(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), question LONGTEXT, response LONGTEXT, autotalkon VARCHAR(10), likes VARCHAR(1000), photo VARCHAR(500), views VARCHAR(500), interactions VARCHAR(500), time TIMESTAMP)";  

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());


$signup2 = "ALTER IGNORE TABLE $date_chat ADD CONSTRAINT question UNIQUE (question)";mysql_query($signup2); //or die('Error, insert query failed, oh shoot, it failed.---------------2b');





$signquery4 = "CREATE TABLE IF NOT EXISTS $date_shares(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), question LONGTEXT, response LONGTEXT, autotalkon VARCHAR(10), likes VARCHAR(1000), photo VARCHAR(500), views VARCHAR(500), interactions VARCHAR(500), shares VARCHAR(500), time TIMESTAMP)";  

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());




$signquery4 = "CREATE TABLE IF NOT EXISTS $date_likes(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), question LONGTEXT, response LONGTEXT, autotalkon VARCHAR(10), likes VARCHAR(1000), photo VARCHAR(500), views VARCHAR(500), interactions VARCHAR(500), time TIMESTAMP)";  

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());





$signquery4 = "CREATE TABLE IF NOT EXISTS $date_requests(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), password VARCHAR(30), month VARCHAR(10), day VARCHAR(10), year VARCHAR(100), sex VARCHAR(50), photo VARCHAR(500), check_mark VARCHAR(500), views VARCHAR(500), interactions VARCHAR(500), time TIMESTAMP)";

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());





  
$signup2 = "ALTER IGNORE TABLE $date_requests ADD CONSTRAINT Bot_frd_req_unique UNIQUE (user_id)";mysql_query($signup2); //or die('Error, insert query failed, oh shoot, it failed.---------------2b');


  
$signup2 = "ALTER IGNORE TABLE $dates ADD CONSTRAINT bot_frd_unique UNIQUE (user_id)";mysql_query($signup2); //or die('Error, insert query failed, oh shoot, it failed.---------------2b');



  
$signquery4 = "CREATE TABLE IF NOT EXISTS $info(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), about VARCHAR(1000), martial_status VARCHAR(500), photo VARCHAR(500), views VARCHAR(500), interactions VARCHAR(500), time TIMESTAMP)";

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());



$signquery4 = "CREATE TABLE IF NOT EXISTS $settings(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), deactivate VARCHAR(50), send_emails VARCHAR(50), sound VARCHAR(50), stealthmode VARCHAR(50), delete_account VARCHAR(50), views VARCHAR(500), interactions VARCHAR(500), botmode VARCHAR(50), time TIMESTAMP)";

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());



$signup3 = "INSERT INTO $settings(id, user_id, firstname, lastname, email, deactivate, send_emails, sound, stealthmode, delete_account, views, interactions, botmode, time) VALUES (NULL, '', '', '', '', '', '', '', '', '', '', '', '', '$time')"; mysql_query($signup3) or die('Error, insert query failed, oh shoot, it failed.---------------2ab');






$signquery4 = "CREATE TABLE IF NOT EXISTS $photos(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), deactivate VARCHAR(50), send_emails VARCHAR(50), sound VARCHAR(50), stealthmode VARCHAR(50), views VARCHAR(500), interactions VARCHAR(500), photo VARCHAR(500), time TIMESTAMP)";

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());




//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$headers = 'From: Faceworld@Faceworld.io' . "\r\n" .
    'Reply-To: Faceworld@Faceworld.io' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
$subject = "".$firstname.", Thanks for joining Faceworld. You mean a lot to us. We are new and you are to, so we are working hard to bring the lastest and greatest of this technology that we have stumbled upon. So, stay tuned, more is to come."; 
$message="".$firstname.", You are number one to us. We value your comments and suggestions in this new website. We are working on Faceworld everyday to improve the user experience for you so that is it for now. Hope to see you soon. :)";
$to = $email;
$send_contact=mail($to,$subject,$message,$headers);


$subject = "".$firstname.", (New user) Thanks for joining Faceworld."; 
$to = "christopherclark999o@gmail.com";
$message= "New user, you are gaining users!!!!!!";
$send_contact=mail($to,$subject,$message,$headers);




$_SESSION['id'] = $id;
$extra = "home.php?id=".$id;
header("Location: http://www.faceworld.io/$extra");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}
else
{

header("Location: http://www.faceworld.io/index.php");
	
}

}
else
{

header("Location: http://www.faceworld.io/index.php");
	
}


}
else
{

header("Location: http://www.faceworld.io/index.php");
	
}

}
else
{

header("Location: http://www.faceworld.io/index.php");
	
}

}
else
{

header("Location: http://www.faceworld.io/index.php");
	
}

}
else
{

header("Location: http://www.faceworld.io/index.php");
	
}

}
else
{

header("Location: http://www.faceworld.io/index.php");
	
}



}
else
{

header("Location: http://www.faceworld.io/index.php");
	
}









}

?>