<?PHP
include 'config.php';
session_start();
$id = $_SESSION['id'];

if(!isset($id))
{
header ("location: http://www.faceworld.io/index.php");	
}



$dates = 'dates'.'_'.$id;
$date_requests = 'date_requests'.'_'.$id;


$signquery4 = "CREATE TABLE IF NOT EXISTS $date_requests(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), password VARCHAR(30), month VARCHAR(10), day VARCHAR(10), year VARCHAR(100), sex VARCHAR(50), photo VARCHAR(500), check_mark VARCHAR(500), views VARCHAR(500), interactions VARCHAR(500), time TIMESTAMP)";

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());




$signquery4 = "CREATE TABLE IF NOT EXISTS $dates(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), password VARCHAR(30), month VARCHAR(10), day VARCHAR(10), year VARCHAR(100), sex VARCHAR(50), photo VARCHAR(500), check_mark VARCHAR(500), views VARCHAR(500), interactions VARCHAR(500), time TIMESTAMP)";

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());


  
$signup2 = "ALTER IGNORE TABLE $date_requests ADD CONSTRAINT Bot_frd_req_unique UNIQUE (user_id)";mysql_query($signup2);


  
$signup2 = "ALTER IGNORE TABLE $dates ADD CONSTRAINT bot_frd_unique UNIQUE (user_id)";mysql_query($signup2); 



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="robots" content="all" /> 
<meta name="robots" content="index, follow" /> 
<meta name="googlebot" content="index, follow" /> 
<meta name="msnbot" content="index, follow" /> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Faceworld | Friend Requests</title>
<link href="css/bot_requests.css" rel="stylesheet" type="text/css" media="screen" />
<meta name="description" content="Faceworld is an utility that connects you to friends and family by location!">
<meta name="keywords" content="social, social network, network" />
<link rel="shortcut icon" href="http://www.faceworld.io/img/favicon.ico">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
 

</head>

<body>
<div id="bx1"></div>

<div id="wrapper">
<form name="input" id="commentForm" action="http://www.faceworld.io/search_results.php" method="post"> 
  <div id="header">
  <div id="site_logo"><a class="white" href="http://www.faceworld.io/profile.php?id=<?PHP echo $id; ?>">Faceworld</a></div>
  <div id="textboxleft">
    <label>
      <input type="text" placeholder="search..." name="search_data" id="search_data" />
    </label>
  </div>
    <div id="txtboxx"><input type="image" src="http://www.faceworld.io/img/find.png" alt="Submit" width="75" height="28"></div>
  <div id="rightboxitems"><b><a class="white" href="http://www.faceworld.io/apps.php?id=<?PHP echo $id; ?>"> Apps </a> | <a class="white" href="http://www.faceworld.io/home.php?id=<?PHP echo $id; ?>"> Home</a> | <a class="white" href="http://www.faceworld.io/profile.php?id=<?PHP echo $id; ?>"> Profile</a> | <a class="white" href="http://www.faceworld.io/find_friends.php?id=<?PHP echo $id; ?>">Find Friends</a> | <a class="white" href="http://www.faceworld.io/friends.php?id=<?PHP echo $id; ?>">Friends</a> | <a class="white" href="http://www.faceworld.io/friend_requests.php?id=<?PHP echo $id; ?>">Requests</a> | <a class="white" href="http://www.faceworld.io/log_out.php">Log out</a></b></div></div>
  </form>
  <div id="cube">
    <div id="findbotsbox">Friend Requests
      <div id="invite_friend_box"></div>
    </div>
  
    <div id="centercol">
      <div id="lcc">
        <?PHP
		
		
			$date_requests = 'date_requests'.'_'.$id;
		
	
		

$query = "SELECT * FROM $date_requests WHERE user_id <> '$id' ORDER BY RAND() LIMIT 100";
$result = mysql_query($query)
or die("Query failed: " . mysql_error());
while ($row = mysql_fetch_assoc($result))
{
$user_id = $row['user_id'];
$firstname = $row['firstname'];
$lastname = $row['lastname'];
$photo = $row['photo'];
$email = $row['email'];
$sex = $row['sex'];
$city = $row['city'];
$state = $row['state'];
$country = $row['country'];
$highschool = $row['highschool'];
$college = $row['college']; 
$type = $row['type'];
$nurse = $row['nurse'];
$doctor = $row['doctor'];
$location = $row['location'];
		
		
		echo'<div id="rect_results_bx">';
        echo'<div id="bot_photo">';
        echo'<div id="p_photo">';
		
		if(!empty($photo))
		{
		echo'<img src="http://www.faceworld.io/uploads/'; echo $photo; echo'" alt="profile photo" width="200" height="200" />'; 
		}
		else
		{
			
			echo'<img src="http://www.faceworld.io/img/'; echo 'heart.png'; echo'" alt="profile photo" width="200" height="200" />'; 
			
		}
		
		echo'</div>';
            
        echo'</div>';
        echo'<div id="info">';
        echo'<strong>';
		echo $firstname.' '.$lastname;
		echo'<br/>';
        echo $location;
		echo'<br/>';
		echo'<br/>';
		echo'<br/>';
		echo'<br/>';
		
		
        echo'</strong>';
		echo'</div>';
        echo'<div id="rightbuttonr">';
        echo'<div id="buttonrrr">';
		echo'<a href="http://www.faceworld.io/friend_requests.php?fid='; echo $user_id;   echo'">';
		echo'<input type="image" src="http://www.faceworld.io/img/add_date.png" name="image" width="128" height="32">';
		echo'</a>';
		echo'</div>';
        echo'<div id="buttonrrr2">';
		echo'<a href="http://www.faceworld.io/friend_requests.php?did='; echo $user_id;   echo'">';
		echo'<input type="image" src="http://www.faceworld.io/img/delete.png" name="image" width="128" height="32">';
		echo'</a>';
		echo'</div>';
        echo'</div>';
        echo'</div>';
		echo'<div id="bottombar">';
		echo'</div>';
		
		
}
		
		?>
        
      </div>
      <div id="rcc">
        <div id="c_right_cube"><form name="input" id="commentForm" action="http://www.faceworld.io/search_results.php" method="post"> 
          <div id="search_title"><strong>Search for friends by name.</strong></div>
          <div id="search_box_row"><input type="text" name="name"  placeholder="E.g. Cameron Diaz" id="name" /></div>
          <div id="find_button_row">
            <div id="find_button_box_r">
              <label>
                <input type="submit" name="button2" id="button2" value="Find" />
              </label>
            </div>
          </div></form>
        </div>
      </div>
    </div>
  </div>
</div>

</body>

</html>

<?PHP

$fid = $_GET['fid'];


if(isset($fid))
{
	
			  
$query = "SELECT * FROM profile WHERE user_id = '$fid'";
$result = mysql_query($query)
or die("Query failed: " . mysql_error());
while ($row = mysql_fetch_assoc($result))
{
$firstname = $row['firstname'];
$lastname = $row['lastname'];
$sex = $row['sex'];
$month = $row['month'];
$day = $row['day'];
$year = $row['year'];
$email = $row['email'];


$f = $row['photo'];
$martialstatus = $row['martialstatus'];

$user_id = $row['user_id'];
}

$dates = 'dates'.'_'.$id;
$time = date("Y-m-d H:i:s");
  
  
  
$signquery4 = "CREATE TABLE IF NOT EXISTS $dates(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), password VARCHAR(30), month VARCHAR(10), day VARCHAR(10), year VARCHAR(100), sex VARCHAR(50), photo VARCHAR(500), check_mark VARCHAR(500), views VARCHAR(500), interactions VARCHAR(500), time TIMESTAMP)";

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());


  


$signup3 = "INSERT INTO $dates (id, user_id, firstname, lastname, email, password, month, day, year, sex, photo, check_mark, views, interactions, time) VALUES (NULL, '$user_id', '$firstname', '$lastname', '$email', '', '$month', '$day', '$year', '$sex', '$f', '', '', '', '$time')"; mysql_query($signup3) or die('Error, insert query failed, oh shoot, it failed.---------------1a');





	  
$query = "SELECT * FROM profile WHERE user_id = '$id'";
$result = mysql_query($query)
or die("Query failed: " . mysql_error());
while ($row = mysql_fetch_assoc($result))
{
$firstname = $row['firstname'];
$lastname = $row['lastname'];
$sex = $row['sex'];
$month = $row['month'];
$day = $row['day'];
$year = $row['year'];
$email = $row['email'];
$country = $row['country'];
$city = $row['city'];
$state = $row['state'];
$highschool = $row['higschool'];
$college = $row['college'];
$f = $row['photo'];

$user_id = $row['user_id'];
}



$dates = 'dates'.'_'.$fid;





$signquery4 = "CREATE TABLE IF NOT EXISTS $dates(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), password VARCHAR(30), month VARCHAR(10), day VARCHAR(10), year VARCHAR(100), sex VARCHAR(50), photo VARCHAR(500), check_mark VARCHAR(500), views VARCHAR(500), interactions VARCHAR(500), time TIMESTAMP)";

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());



$signup3 = "INSERT INTO $dates (id, user_id, firstname, lastname, email, password, month, day, year, sex, photo, check_mark, views, interactions, time) VALUES (NULL, '$user_id', '$firstname', '$lastname', '$email', '', '$month', '$day', '$year', '$sex', '$f', '', '', '', '$time')"; mysql_query($signup3) or die('Error, insert query failed, oh shoot, it failed.---------------1a');



$query = "SELECT * FROM profile WHERE user_id = '$fid'";
$result = mysql_query($query)
or die("Query failed: " . mysql_error());
while ($row = mysql_fetch_assoc($result))
{

$firstname2 = $row['firstname'];
$email = $row['email'];
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$headers = 'From: Faceoworld@faceworld.io' . "\r\n" .
    'Reply-To: Faceworld@faceworld.io' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
$subject = "".$firstname2.", Congradulations!!!, You now have a friend to talk to!!!"; 
$message="".$firstname2.", Yeah, You have a friend named:".$firstname." ".$lastname." , Log on to Faceworld at the following address and get to know your new friend!!! You might learn a lot!!!: http://www.faceworld.io/index.php";
$to = $email;
$send_contact=mail($to,$subject,$message,$headers);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////




}
	
	
	




$did = $_GET['did'];


if(isset($did))
{
	




$date_requests = 'date_requests'.'_'.$id;

$signquery4 = "DELETE FROM $date_requests
        WHERE user_id = '$did'";

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1 ".mysql_error());
   }
		
				
		
		
		





?>




<?php include_once("analyticstracking.php") ?>
