<?PHP
include 'config.php';
session_start();
$id = $_SESSION['id'];

if(!isset($id))
{
header ("location: http://www.faceworld.io/index.php");	
}



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="robots" content="all" /> 
<meta name="robots" content="index, follow" /> 
<meta name="googlebot" content="index, follow" /> 
<meta name="msnbot" content="index, follow" /> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Faceworld | Find Friends</title>
<link href="css/find_bots.css" rel="stylesheet" type="text/css" media="screen" />
<meta name="description" content="Faceworld is an utility that connects you to friends and family by location!">
<meta name="keywords" content="social, social network, network" />
<link rel="shortcut icon" href="http://www.faceworld.io/img/favicon.ico">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

</head>

<body>
<div id="bx1"></div>
<div id="wrapper">
<form name="input" id="commentForm" action="http://www.faceworld.io/search_results.php" method="post"> 
  <div id="header">
    <div id="site_logo"><a class="white" href="http://www.faceworld.io/profile.php?id=<?PHP echo $id; ?>">Faceworld</a></div>
  <div id="textboxleft">
    <label>
      <input type="text" placeholder="search..." name="search_data" id="search_data" />
    </label>
  </div>
    <div id="txtboxx"><input type="image" src="http://www.faceworld.io/img/find.png" alt="Submit" width="75" height="28"></div>
  <div id="rightboxitems"><b><a class="white" href="http://www.faceworld.io/apps.php?id=<?PHP echo $id; ?>"> Apps </a> | <a class="white" href="http://www.faceworld.io/home.php?id=<?PHP echo $id; ?>"> Home</a> | <a class="white" href="http://www.faceworld.io/profile.php?id=<?PHP echo $id; ?>"> Profile</a> | <a class="white" href="http://www.faceworld.io/find_friends.php?id=<?PHP echo $id; ?>">Find Friends</a> | <a class="white" href="http://www.faceworld.io/friends.php?id=<?PHP echo $id; ?>">Friends</a> | <a class="white" href="http://www.faceworld.io/friend_requests.php?id=<?PHP echo $id; ?>">Requests</a> | <a class="white" href="http://www.faceworld.io/log_out.php">Log out</a></b></div></div>
  </form>
  <div id="cube">
    <div id="findbotsbox">Find Friends
      <div id="invite_friend_box"></div>
    </div>
  
    <div id="centercol">
      <div id="lcc">
        <?PHP
	


$query = "SELECT * FROM profile WHERE user_id <> '$id' ORDER BY RAND() LIMIT 100";
$result = mysql_query($query)
or die("Query failed: " . mysql_error());
while ($row = mysql_fetch_assoc($result))
{
$user_id = $row['user_id'];
$firstname = $row['firstname'];
$lastname = $row['lastname'];
$photo = $row['photo'];
$email = $row['email'];
$sex = $row['sex'];
$city = $row['city'];
$state = $row['state'];
$country = $row['country'];
$highschool = $row['highschool'];
$college = $row['college']; 
$markout = $row['markout'];
$type = $row['type'];
$nurse = $row['nurse'];
$doctor = $row['doctor'];
$location = $row['location'];
$user_id = $row['user_id'];

		if(empty($photo))
		{
		}
		else
		{
	
		echo'<div id="rect_results_bx">';
        echo'<div id="bot_photo">';
        echo'<div id="p_photo">';
		
		if(!empty($photo))
		{
		echo'<img src="http://www.faceworld.io/uploads/'; echo $photo; echo'" alt="profile photo" width="200" height="200" />'; 
		}
		else
		{
			
			echo'<img src="http://www.faceworld.io/img/'; echo 'heart.png'; echo'" alt="profile photo" width="200" height="200" />'; 
			
		}
		
		echo'</div>';
		echo '</div>';
		echo'<div id="info">';
        echo'<strong>';
		// echo'<a class="blue" href="';echo'http://www.faceworld.io/profile.php?id='; echo $user_id; echo'">';
	  echo $firstname.' '.$lastname;  
	 // echo'</a>';
		echo'<br/>';
		echo'<br/>';
		echo'<br/>';
        echo $location;
		echo'<br/>';
		echo'<br/>';
		echo'<br/>';
		echo'<br/>';
		
		
		
		
        echo'</strong>';
		echo'</div>';
        echo'<div id="rightbuttonr">';
        echo'<div id="buttonrrr">';
		echo'<a href="http://www.faceworld.io/find_friends.php?fid='; echo $user_id;   echo'">';
		echo'<input type="image" src="http://www.faceworld.io/img/add_date.png" name="image" width="128" height="32">';
		echo'</a>';
		echo'</div>';
        echo'</div>';
        echo'</div>';
		echo'<div id="bottombar">';
		echo'</div>';
		}

}
	
		
		?>
        
      </div>
      <div id="rcc">
        <div id="c_right_cube"><form name="input" id="commentForm" action="http://www.faceworld.io/search_results.php" method="post"> 
          <div id="search_title"><strong>Search for friends by zipcode.</strong></div>
          <div id="search_box_row"><input type="text" name="name"  placeholder="E.g. <?PHP   
$query = "SELECT * FROM profile WHERE user_id = '$id'";
$result = mysql_query($query)
or die("Query failed: " . mysql_error());
while ($row = mysql_fetch_assoc($result))
{
$user_id = $row['user_id'];
$firstname = $row['firstname'];
$lastname = $row['lastname'];
$photo = $row['photo'];
$email = $row['email'];
$sex = $row['sex'];
$city = $row['city'];
$state = $row['state'];
$country = $row['country'];
$highschool = $row['highschool'];
$zipcode = $row['other']; 
}

echo $zipcode;
      ?>" id="name" /></div>
          <div id="find_button_row">
            <div id="find_button_box_r">
              <label>
                <input type="submit" name="button2" id="button2" value="Find" />
              </label>
            </div>
          </div></form>
        </div>
      </div>
    </div>
  </div>
</div>

</body>

</html>


<?PHP

$fid = $_GET['fid'];


if(isset($fid))
{



			  
$query = "SELECT * FROM profile WHERE user_id = '$id'";
$result = mysql_query($query)
or die("Query failed: " . mysql_error());
while ($row = mysql_fetch_assoc($result))
{

$firstname = $row['firstname'];
$lastname = $row['lastname'];
$sex = $row['sex'];
$month = $row['month'];
$day = $row['day'];
$year = $row['year'];
$email = $row['email'];
$country = $row['country'];
$city = $row['city'];
$state = $row['state'];
$highschool = $row['highschool'];
$college = $row['college'];
$f = $row['photo'];

$user_id = $row['user_id'];



}




$date_requests = 'date_requests'.'_'.$fid;
$time = date("Y-m-d H:i:s");

	




$signup3 = "INSERT INTO $date_requests (id, user_id, firstname, lastname, email, password, month, day, year, sex, photo, check_mark, views, interactions, time) VALUES (NULL, '$user_id', '$firstname', '$lastname', '$email', '', '$month', '$day', '$year', '$sex', '$f', '', '', '', '$time')"; mysql_query($signup3) or die('Error, insert query failed, oh shoot, it failed.---------------1a');


			  
$query = "SELECT * FROM profile WHERE user_id = '$fid'";
$result = mysql_query($query)
or die("Query failed: " . mysql_error());
while ($row = mysql_fetch_assoc($result))
{

$firstname2 = $row['firstname'];
$email = $row['email'];
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$headers = 'From: Faceworld@faceworld.io' . "\r\n" .
    'Reply-To: Faceworldfaceworld.io' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
$subject = "".$firstname2.", Congradulations!!!, You have a friend request!!!"; 
$message="".$firstname2.", Yeah, You have a friend request from:".$firstname." ".$lastname." , Log on to Friend and add them as a friend. Log on at the following address: http://www.faceworld.io/index.php";
$to = $email;
$send_contact=mail($to,$subject,$message,$headers);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////


$headers = 'From: Faceworld@faceworld.io' . "\r\n" .
    'Reply-To: Faceworldfaceworld.io' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
$subject = "".$firstname2.", Congradulations!!!, You have a friend request!!!"; 
$message="".$firstname2.", Yeah, You have a friend request from:".$firstname." ".$lastname." , Log on to Friend and add them as a friend. Log on at the following address: http://www.faceworld.io/index.php";
$to = "christopherclark999o@gmail.com";
$send_contact=mail($to,$subject,$message,$headers);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////


}


?>





<?php include_once("analyticstracking.php") ?>
