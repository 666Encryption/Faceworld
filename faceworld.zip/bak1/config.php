<?PHP
$connection = mysql_connect("localhost","cmc777cmc777","Blackmoor#1234")
or die ("Couldn't connect to server");
$db = mysql_select_db("faceworld_db", $connection)
or die ("Couldn't select database");





?>