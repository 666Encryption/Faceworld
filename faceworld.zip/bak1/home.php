<?PHP
include 'config.php';
session_start();
$id = $_SESSION['id'];

if(empty($id))
{
header ("location: http://www.faceworld.io/index.php");	
}

if(!empty($_POST['data']))
{

$query = "SELECT * FROM profile WHERE user_id = '$id'";
$result = mysql_query($query)
or die("Query failed: " . mysql_error());
while ($row = mysql_fetch_assoc($result))
{
$firstname = $row['firstname'];
$lastname = $row['lastname'];  
  
$photo = $row['photo'];  
	
}
$get = $_GET['id'];
$data = $_POST['data'];

$data = htmlspecialchars($data);
$data = strip_tags($data);
$data = addslashes($data);



$signquery4 = "CREATE TABLE IF NOT EXISTS date_chat(id INT(9) NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100), email VARCHAR(350), question LONGTEXT, response LONGTEXT, autotalkon VARCHAR(10), likes VARCHAR(1000), photo VARCHAR(500), views VARCHAR(500), interactions VARCHAR(500), time TIMESTAMP)";  

$signquery = mysql_query($signquery4)
or die("Query failed:Pow, It failed!-------------1".mysql_error());

$time = date("Y-m-d H:i:s");
$signup3 = "INSERT INTO date_chat (id, user_id, firstname, lastname, email, question, response, autotalkon, likes, photo, views, interactions, time) VALUES (NULL, '$id', '$firstname', '$lastname', '', '$data', '', '', '', '$photo', '', '', '$time')"; mysql_query($signup3) or die('Error, insert query failed, oh shoot, it failed.---------------1a');

}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="robots" content="all" /> 
<meta name="robots" content="index, follow" /> 
<meta name="googlebot" content="index, follow" /> 
<meta name="msnbot" content="index, follow" /> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Faceworld | Home</title>
<link href="css/home.css" rel="stylesheet" type="text/css" media="screen" />
<meta name="description" content="Faceworld is an utility that connects you to friends and family by location!">
<meta name="keywords" content="social, social network, network" />
<link rel="shortcut icon" href="http://www.faceworld.io/img/favicon.ico">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />


</head>

<body>
<div id="wrapper">
  <div id="bx1"></div>

  
  <div id="header">
    <div id="site_logo"><a class="white" href="http://www.faceworld.io/profile.php?id=<?PHP echo $id; ?>">Faceworld</a></div> <form action="http://www.faceworld.io/search_results.php" id="signupForm" method="post">
  <div id="textboxleft"> 
    <label>
      <input type="text" placeholder=" search..." name="search_data" id="search_data" />
    </label>
  </div>
    <div id="txtboxx"><input type="image" src="http://www.faceworld.io/img/find.png" alt="Submit" width="75" height="28"></form></div>
  <div id="rightboxitems"><b><a class="white" href="http://www.faceworld.io/apps.php?id=<?PHP echo $id; ?>"> Apps </a> | <a class="white" href="http://www.faceworld.io/home.php?id=<?PHP echo $id; ?>"> Home</a> | <a class="white" href="http://www.faceworld.io/profile.php?id=<?PHP echo $id; ?>"> Profile</a> | <a class="white" href="http://www.faceworld.io/find_friends.php?id=<?PHP echo $id; ?>">Find Friends</a> | <a class="white" href="http://www.faceworld.io/friends.php?id=<?PHP echo $id; ?>">Friends</a> | <a class="white" href="http://www.faceworld.io/friend_requests.php?id=<?PHP echo $id; ?>">Requests</a> | <a class="white" href="http://www.faceworld.io/log_out.php">Log out</a></b></div></div>
  <div id="cube">
    <div id="leftcol">
      <div id="datesboxj"></div>
      <div id="datesboxes"></div>
    </div>
    <div id="center">
      <div id="chat_box">
        <div id="titleline">
          <div id="ppbox"> 
            <p>Home</p>
</div>
        </div>
        <form action="http://www.faceworld.io/home.php?id=<?PHP echo $_GET['id'];  ?>" id="signupForm" method="post" >
        <div id="txtchatbox">
          <div id="cboxx"><textarea name="data" placeholder="Share something..." cols="60" rows="5"></textarea></div>
        </div>
        <div id="buttonbox">
          <div id="buttonbox3">
            <label>
              <input type="image" src="http://www.faceworld.io/img/post.png" alt="Submit" width="75" height="28" />
            </label></form>
      </div>
    </div>
  </div>
      
	 <?PHP
	 $get = $_GET['id'];
	 // $date_chat = 'date_chat'.'_'.$get;
	  $query = "SELECT * FROM date_chat ORDER BY id DESC LIMIT 100";
$result = mysql_query($query)
or die("Query failed: " . mysql_error());
while ($row = mysql_fetch_assoc($result))
{
$firstname = $row['firstname'];
$lastname = $row['lastname'];  
$question = $row['question'];  
$photo = $row['photo'];  
$user_id = $row['user_id']; 

	 echo'<div id="areabox">';
	 echo'<div id="ccboxxy">';
	 echo'<div id="c50">';
	 
	 	
		if(!empty($photo))
		{
		echo'<img src="http://www.faceworld.io/uploads/'; echo $photo; echo'" alt="home photo" width="50" height="50" />'; 
		}
		else
		{
			
			echo'<img src="http://www.faceworld.io/img/'; echo 'heart.png'; echo'" alt="blank photo" width="50" height="50" />'; 
			
		}
	 
	 echo'</div>';
     echo'<div id="nameyboxy">';
	 echo'<a class="blue" href="';echo'http://www.faceworld.io/profile.php?id='; echo $user_id; echo'">';
	  echo $firstname.' '.$lastname;  
	  echo'</a>';
	 echo'</div>';
     echo'</div>';
     
	echo'<div id="message">';
	echo'<div id="msgbxx">';
	
	echo $question;
	
	echo'</div>';
	echo'</div>';
     
   echo'<div id="photoboxcd">';
   echo'</div>';
   echo'</div>';
	 
}
	 
	 ?>

	  
</div>
    <div id="rightcol"></div>
  </div>
</div>

</body>

</html>

  
	 