<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="robots" content="all" /> 
<meta name="robots" content="index, follow" /> 
<meta name="googlebot" content="index, follow" /> 
<meta name="msnbot" content="index, follow" /> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Faceworld</title>
<link href="css/index.css" rel="stylesheet" type="text/css" media="screen" />
<meta name="description" content="Faceworld is an utility that connects you to friends and family by location!">
<meta name="keywords" content="social, social network, network" />
<link rel="shortcut icon" href="http://www.faceworld.io/img/favicon.ico">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<script type=”text/javascript”>
  <!–
  if (screen.width <= 1000) {
    window.location = “http://m.faceworld.io”;
  }
  //–>
</script>

</head>

<body>
<div id="250075869">
   
</div>
<div id="wrapper">

  <div id="header">
    <div id="center_box">
      <div id="face_logo"><img src="http://www.faceworld.io/img/bot.jpg" alt="" width="50" height="50" /></div>
      <div id="rightbox"><strong><a class="white" href="http://www.faceworld.io/index.php">Faceworld</a></strong></div>
    </div>
    <div id="rightmenubox">
      <div id="menur">
        <div id="email_title"><strong>Email</strong></div>
        <div id="password_title"><strong>Password</strong></div>
      </div><form id="submit" action="get_signin.php" method="post">
      <div id="menu2">
        <div id="email_box">
          <label>
            <input type="text" name="email2" maxlength="350" placeholder="name@domain.com" id="email2" />
          </label>
        </div>
        <div id="password_box">
          <label>
            <input type="password" name="password2" maxlength="30" placeholder="**************" id="password2" />
          </label>
        </div>
        <div id="button_box"><input type="image" src="http://www.faceworld.io/img/login.png" name="image" width="73" height="28"></div>
      </div></form>
      <div id="rightpassword"><strong><a class="white" href="http://www.faceworld.io/forgot_password.php">Forgot Password ?</a></strong></div>
    </div>
  </div>
  <div id="cube">
    
      <div id="rect_box">
        <div id="leftcol">
          <div id="lcolbox">
          <div id="site_description"><strong>Faceworld is an utility that connects you to friends and family by location!</strong></div>
          <div id="details_box">
            <p><strong>Share things with friends.</strong></p>
            <p><strong>Find friends to chat to.</strong></p>
          </div>
          <div id="xbox">
            <p>Plus, much, much, more.<br />
            </p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
          </div></div>
        
          
          <div id="rightvbar"></div>
        </div>
         <div id="rightcol">
           <div id="rightcube">
             <div id="signupbox"><strong>Sign up | It's free forever!!!</strong></div>
           
            <form action="http://www.faceworld.io/get_type.php" id="signupForm" method="post" enctype="multipart/form-data">
             <div id="firstnamelastnametitle">
               <div id="firstbox"><strong>First name</strong></div>
               <div id="lastbox"><strong>Last name</strong></div>
             </div>
           
        
             <div id="firstnamelastnamebox">
               <div id="lcfirstnamebox">
                 <label>
                   
                 </label><input type="text" name="firstname" maxlength="100" placeholder="E.g. Molly" id="firstname" />
               </div>
               <div id="fclastnamebox"> <label>
                   <input type="text" name="lastname" maxlength="100" placeholder="E.g. Anderson" id="lastname" />
               </label></div>
             </div>
           
             <div id="emails_title">Email</div>
           
           
             <div id="emails_box"><label>
                   <input type="text" name="email" maxlength="350" placeholder="E.g. name@domain.com" id="email" />
             </label></div>
           
           
             <div id="passtitle"><strong>Password</strong></div>
           
             <div id="passbox"><label>
                   <input type="password" name="password" maxlength="30" placeholder="***************" id="password" />
             </label></div>
           
           
             <div id="birthday_title"><strong>Birthday</strong></div>
           
           
             <div id="birthdaybox"><select name="month" id="month">
      <option>Month</option>
      <option>1</option>
      <option>2</option>
      <option>3</option>
      <option>4</option>
      <option>5</option>
      <option>6</option>
      <option>7</option>
      <option>8</option>
      <option>9</option>
      <option>10</option>
      <option>11</option>
      <option>12</option>
        </select>  <select name="day" id="day">
          <option>Day</option>
          <option>1</option>
          <option>2</option>
          <option>3</option>
          <option>4</option>
          <option>5</option>
          <option>6</option>
          <option>7</option>
          <option>8</option>
          <option>9</option>
          <option>10</option>
          <option>11</option>
          <option>12</option>
          <option>13</option>
          <option>14</option>
          <option>15</option>
          <option>16</option>
          <option>17</option>
          <option>18</option>
          <option>19</option>
          <option>20</option>
          <option>21</option>
          <option>22</option>
          <option>23</option>
          <option>24</option>
          <option>25</option>
          <option>26</option>
          <option>27</option>
          <option>28</option>
          <option>29</option>
          <option>30</option>
          <option>31</option>
           </select>
        <select name="year" id="year">
          <option>Year</option>
          <option>2021</option>
          <option>2020</option>
          <option>2019</option>
          <option>2018</option>
          <option>2017</option>
          <option>2016</option>
          <option>2015</option>
          <option>2014</option>
          <option>2013</option>
          <option>2012</option>
          <option>2011</option>
          <option>2010</option>
          <option>2009</option>
          <option>2008</option>
          <option>2007</option>
          <option>2006</option>
          <option>2005</option>
          <option>2004</option>
          <option>2003</option>
          <option>2002</option>
          <option>2001</option>
          <option>2000</option>
          <option>1999</option>
          <option>1998</option>
          <option>1997</option>
          <option>1996</option>
          <option>1995</option>
          <option>1994</option>
          <option>1993</option>
          <option>1992</option>
          <option>1991</option>
          <option>1990</option>
          <option>1989</option>
          <option>1988</option>
          <option>1987</option>
          <option>1986</option>
          <option>1985</option>
          <option>1984</option>
          <option>1983</option>
          <option>1982</option>
          <option>1981</option>
          <option>1980</option>
          <option>1979</option>
          <option>1978</option>
          <option>1977</option>
          <option>1976</option>
          <option>1975</option>
          <option>1974</option>
          <option>1973</option>
          <option>1972</option>
          <option>1971</option>
          <option>1970</option>
          <option>1969</option>
          <option>1968</option>
          <option>1967</option>
          <option>1966</option>
          <option>1965</option>
          <option>1964</option>
          <option>1963</option>
          <option>1962</option>
          <option>1961</option>
          <option>1960</option>
          <option>1959</option>
          <option>1958</option>
          <option>1957</option>
          <option>1956</option>
          <option>1955</option>
          <option>1954</option>
          <option>1953</option>
          <option>1952</option>
          <option>1951</option>
          <option>1950</option>
          <option>1949</option>
          <option>1948</option>
          <option>1947</option>
          <option>1946</option>
          <option>1945</option>
          <option>1944</option>
          <option>1943</option>
          <option>1942</option>
          <option>1941</option>
          <option>1940</option>
          <option>1939</option>
          <option>1938</option>
          <option>1937</option>
          <option>1936</option>
          <option>1935</option>
          <option>1934</option>
          <option>1933</option>
          <option>1932</option>
          <option>1931</option>
          <option>1930</option>
          <option>1929</option>
          <option>1928</option>
          <option>1927</option>
          <option>1926</option>
          <option>1925</option>
          <option>1924</option>
          <option>1923</option>
          <option>1922</option>
          <option>1921</option>
          <option>1920</option>
          <option>1919</option>
          <option>1918</option>
          <option>1917</option>
          <option>1916</option>
          <option>1915</option>
          <option>1914</option>
          <option>1913</option>
          <option>1912</option>
          <option>1911</option>
          <option>1910</option>
          <option>1909</option>
          <option>1908</option>
          <option>1907</option>
          <option>1906</option>
          <option>1905</option>
          <option>1904</option>
          <option>1903</option>
          <option>1902</option>
          <option>1901</option>
          <option>1900</option>
        </select></div>
           
             <div id="sex_title"><strong>Sex</strong></div>
             <div id="sex_box"><select name="sex" id="sex">
          <option>Select Sex</option>
          <option>Female</option>
          <option>Male</option>
        </select></div>
             <div id="whatareyou">Zip Code</div>
             <div id="whatareyou">
               <label>
                 <input type="text" placeholder="E.g. 39399" name="zipcode" id="zipcode" />
               </label>
             </div>
             
           
             <div id="button_agreements">
               
               <div id="join_agreements"> By clicking join, I agree to the <a class="white" href="http://www.faceworld.io/terms.php">terms</a> and <a class="white" href="http://www.faceworld.io/privacy.php">privacy agreements</a>.</div>
               <div id="rightbuttonjoin"><input type="image" src="http://www.faceworld.io/img/join.png" name="image2" width="87" height="35" /></div>
             </div>
           </div>
         </div>
    </div>
  </form>
<div id="footer">
  <div id="bx1"><strong><a class="gray" href="http://www.faceworld.io/about.php">About</a> | <a class="gray" href="http://www.faceworld.io/contact.php">Contact</a> | <a class="gray" href="http://www.faceworld.io/terms.php">Terms</a> | <a class="gray" href="http://www.faceworld.io/privacy.php">Privacy</a> | <a class="gray" href="http://www.faceworld.io/blog/index.php">Blog</a> |  <a class="gray" href="http://www.faceworld.io/investors.php">Investors</a> <a class="gray" href="http://www.faceworld.io/index.php">|   &copy; 2023 Faceworld</a></strong></div>
  <div id="bx2"></div>
</div>
  </div>
<!-- Go to www.addthis.com/dashboard to customize your tools --> <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5f4153b0db0d1c80"></script>

</body>

</html>

<?PHP     include 'analyticstracking.php';            ?>


